# Strings
Some operations on strings
